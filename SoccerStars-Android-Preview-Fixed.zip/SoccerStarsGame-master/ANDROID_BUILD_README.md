# Android preview build

This is a first Android packaging attempt for the original Pygame game. It launches directly into a local 2-player match and skips the Tkinter menus and network/server mode.

## Build
- Push this project to GitHub.
- Open Actions → Build SoccerStars Android APK → Run workflow (or push to `main`).
- Download the `SoccerStars-debug-APK` artifact from the completed workflow.

The build has not been verified in this environment; Pygame/NumPy Android packaging may need workflow or recipe adjustments.
