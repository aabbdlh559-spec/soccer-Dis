"""Standalone launcher for the SoccerStars Pygame match (no menus/network)."""
import os
os.environ.setdefault("SDL_HINT_ORIENTATIONS", "Portrait")

from src.Game import Game


def main():
    game = Game(is_multiplayer=False)
    game.pygame_init()
    game.load_assets()
    game.board.init_objects()
    game.left_side_name = "RED"
    game.right_side_name = "BLUE"
    game.run()


if __name__ == "__main__":
    main()
