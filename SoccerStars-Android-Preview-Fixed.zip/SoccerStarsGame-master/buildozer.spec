[app]
title = SoccerStars Preview
package.name = soccerstarspreview
package.domain = org.openai.preview
source.dir = .
source.include_exts = py,png,jpg,jpeg,gif,mp3
source.exclude_dirs = .git,__pycache__,log,server
version = 0.1
requirements = python3,pygame,numpy,pillow
orientation = portrait
fullscreen = 1
android.permissions = INTERNET
android.api = 35
android.minapi = 23
android.archs = arm64-v8a
android.accept_sdk_license = True
p4a.branch = master

[buildozer]
log_level = 2
warn_on_root = 1
